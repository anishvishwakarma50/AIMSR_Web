import React from 'react';
import { motion } from 'framer-motion';
import { FaCalendarAlt, FaDownload, FaExternalLinkAlt } from 'react-icons/fa';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const NoticesPage = () => {
  const notices = [
    {
      id: 1,
      date: '2025-01-15',
      title: 'Admission Registration for 2025-26',
      description: 'Online registration for all programs has commenced. Last date to apply is March 31, 2025.',
      type: 'Admission',
      urgent: true
    },
    {
      id: 2,
      date: '2025-01-12',
      title: 'Library Extended Hours During Exams',
      description: 'The library will remain open 24/7 during the examination period from February 1-28, 2025.',
      type: 'Academic',
      urgent: false
    },
    {
      id: 3,
      date: '2025-01-10',
      title: 'Scholarship Applications Open',
      description: 'Merit-based scholarships are now available for eligible students. Apply before February 15, 2025.',
      type: 'Scholarship',
      urgent: false
    },
    {
      id: 4,
      date: '2025-01-08',
      title: 'Campus Placement Drive Schedule',
      description: 'Multiple companies will be conducting placement drives from January 20-30, 2025.',
      type: 'Placement',
      urgent: true
    },
    {
      id: 5,
      date: '2025-01-05',
      title: 'Annual Technical Symposium 2025',
      description: 'TechFest 2025 will be held on March 15-17, 2025. Registration for participants is now open.',
      type: 'Event',
      urgent: false
    }
  ];

  const upcomingEvents = [
    {
      id: 1,
      title: 'Industry Expert Lecture Series',
      date: '2025-01-25',
      time: '2:00 PM - 4:00 PM',
      venue: 'Main Auditorium',
      speaker: 'Mr. Rajesh Gupta, CTO, TechCorp',
      description: 'Insights into emerging technologies and career opportunities in IT industry.'
    },
    {
      id: 2,
      title: 'Career Counseling Workshop',
      date: '2025-01-30',
      time: '10:00 AM - 12:00 PM',
      venue: 'Conference Hall B',
      speaker: 'Dr. Priya Sharma, Career Counselor',
      description: 'Professional guidance for final year students on career planning and job search strategies.'
    },
    {
      id: 3,
      title: 'Research Paper Presentation',
      date: '2025-02-05',
      time: '9:00 AM - 5:00 PM',
      venue: 'Seminar Hall',
      speaker: 'Faculty & Students',
      description: 'Annual research paper presentation by faculty and Ph.D. scholars.'
    }
  ];

  const pastEvents = [
    'https://images.pexels.com/photos/1438072/pexels-photo-1438072.jpeg',
    'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg',
    'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg',
    'https://images.pexels.com/photos/3184337/pexels-photo-3184337.jpeg'
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <motion.section
        className="relative h-96 bg-gradient-to-r from-blue-900 to-blue-700 flex items-center justify-center text-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <div className="text-center">
          <motion.h1 
            className="text-5xl font-bold mb-4"
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            Notices & Events
          </motion.h1>
          <motion.p 
            className="text-xl"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            Stay Updated with Latest Announcements and Events
          </motion.p>
        </div>
      </motion.section>

      {/* Notices Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: -30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Latest Notices</h2>
            <p className="text-xl text-gray-600">Important announcements and updates</p>
          </motion.div>

          <div className="space-y-6">
            {notices.map((notice, index) => (
              <motion.div
                key={notice.id}
                className={`bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 border-l-4 ${
                  notice.urgent ? 'border-red-500' : 'border-blue-500'
                }`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4 mb-3">
                      <span className="text-sm text-gray-500 flex items-center">
                        <FaCalendarAlt className="mr-2" />
                        {new Date(notice.date).toLocaleDateString()}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        notice.urgent 
                          ? 'bg-red-100 text-red-600' 
                          : 'bg-blue-100 text-blue-600'
                      }`}>
                        {notice.type}
                      </span>
                      {notice.urgent && (
                        <span className="px-2 py-1 bg-red-500 text-white rounded text-xs font-bold">
                          URGENT
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{notice.title}</h3>
                    <p className="text-gray-600">{notice.description}</p>
                  </div>
                  <div className="flex space-x-2 mt-4 md:mt-0">
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-300 flex items-center">
                      <FaDownload className="mr-2" />
                      Download
                    </button>
                    <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition-colors duration-300 flex items-center">
                      <FaExternalLinkAlt className="mr-2" />
                      View
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: -30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Upcoming Events</h2>
            <p className="text-xl text-gray-600">Mark your calendars for these exciting events</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {upcomingEvents.map((event, index) => (
              <motion.div
                key={event.id}
                className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                whileHover={{ y: -5 }}
              >
                <div className="mb-4">
                  <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
                    {new Date(event.date).toLocaleDateString()}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{event.title}</h3>
                <div className="space-y-2 mb-4">
                  <p className="text-gray-600"><strong>Time:</strong> {event.time}</p>
                  <p className="text-gray-600"><strong>Venue:</strong> {event.venue}</p>
                  <p className="text-gray-600"><strong>Speaker:</strong> {event.speaker}</p>
                </div>
                <p className="text-gray-600 mb-4">{event.description}</p>
                <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-300">
                  Register Now
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Past Events Gallery */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: -30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Past Events Gallery</h2>
            <p className="text-xl text-gray-600">Highlights from our recent events</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {pastEvents.map((image, index) => (
              <motion.div
                key={index}
                className="relative overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <img
                  src={image}
                  alt={`Past Event ${index + 1}`}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 text-white">
                    <p className="text-sm">Event {index + 1}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default NoticesPage;