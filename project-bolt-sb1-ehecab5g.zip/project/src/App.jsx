import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import AdmissionsPage from './pages/AdmissionsPage';
import PlacementPage from './pages/PlacementPage';
import GalleryPage from './pages/GalleryPage';
import LibraryPage from './pages/LibraryPage';
import NoticesPage from './pages/NoticesPage';
import AdministrationPage from './pages/AdministrationPage';
import CareersPage from './pages/CareersPage';
import MandatoryDisclosurePage from './pages/MandatoryDisclosurePage';
import ContactPage from './pages/ContactPage';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/admissions" element={<AdmissionsPage />} />
          <Route path="/placements" element={<PlacementPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/library" element={<LibraryPage />} />
          <Route path="/notices" element={<NoticesPage />} />
          <Route path="/administration" element={<AdministrationPage />} />
          <Route path="/careers" element={<CareersPage />} />
          <Route path="/mandatory-disclosure" element={<MandatoryDisclosurePage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;